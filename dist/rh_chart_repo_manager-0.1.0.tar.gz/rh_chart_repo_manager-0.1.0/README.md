# Scripts Bundling PoC

This repo contains a point-in-time snapshot of the scripts from
[openshift-helm-charts/development](https://github.com/openshift-helm-charts/development).

Its purpose is to test GitHub Actions workflow related to the installation of
the source contained here.